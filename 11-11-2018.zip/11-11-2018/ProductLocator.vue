<template lang="html">
    <div>
        <section class="filters">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h2>Product Locator Tool</h2>
                        <div class="box">
                            <form action="" class="form-inline">
                                <div class="col-lg-12">
                                    <div class="content">
                                        <div class="row">
                                            <div class="col-12 col-sm-4 col-md-4 col-lg-2 col-xl-2 form-group">
                                                <div class="selectdiv ">
                                                    <label for="">Chains</label>
                                                    <select name="" id="" class="form-control">
                                                                                   <option value="All">All</option>
                                                                                   <option value="All">All</option>
                                                                                </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-md-4 col-lg-2 col-xl-2 form-group">
                                                <div class="selectdiv ">
                                                    <label for="">Stores</label>
                                                    <select name="" id="" class="form-control">
                                                                                   <option value="All">All</option>
                                                                                   <option value="All">All</option>
                                                                                </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-md-4 col-lg-2 col-xl-2 form-group">
                                                <div class="selectdiv ">
                                                    <label for="">Categories</label>
                                                    <select name="" id="" class="form-control">
                                                                                   <option value="All">All</option>
                                                                                   <option value="All">All</option>
                                                                                </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-4 col-md-4 col-lg-2 col-xl-2 form-group">
                                                <div class="selectdiv">
                                                    <label for="">Shelf Types</label>
                                                    <select name="" id="" class="form-control">
                                                                                   <option value="All">All</option>
                                                                                   <option value="All">All</option>
                                                                                </select>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-8 col-md-8 col-lg-4 col-xl-4 form-group calendar">
                                                <label for="">Collection Date</label>
                                                <div class="row">
                                                    <div class="col-6 col-sm-6 col-md-6">
                                                        <div class="input-group date" id="CollectionDate">
                                                            <input type="text" class="form-control" placeholder="From">
                                                            <span class="input-group-addon">
                                                                                      <i class="fa fa-calendar" aria-hidden="true"></i>
                                                                                      </span>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 col-sm-6 col-md-6">
                                                        <div class="input-group date" id="CollectionDate">
                                                            <input type="text" class="form-control" placeholder="To">
                                                            <span class="input-group-addon">
                                                                                      <i class="fa fa-calendar" aria-hidden="true"></i>
                                                                                      </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <input type="button" @click="isSearch = false" class="form-control btn-primary form-btn" value="Search">
                                        </div>
                                        <div class="form-group">
                                            <input type="button" @click="isSearch = true" class="form-control btn-primary form-btn" value="Reset" style="margin-left: 15px;background-color:#F1F1F1 !important;color:black;min-width:100px;">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div v-bind:class="{ 'd-none': isEdit === true }">
            <section class="intro" v-bind:class="{ 'd-none': isSearch === false }">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="box">
                                <div class="external-user">
                                    <p class="description-style">NAME CHAIN IMAGES #</p>
                                </div>
                                <div class="content">
                                    <div class="list-wrapper1">
                                        <img src="../assets/images/list.png" alt="List" />
                                        <p>Search your list information</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="intro" v-bind:class="{ 'd-none': isSearch === true }">
                <div class="container-fluid">
                    <div class="footer img-info">
                        <div class="row ">
                            <div class="col-12 col-sm-6 col-lg-6">
                            </div>
                            <div class="col-12 col-sm-6 col-lg-6">
                                <div class="pull-right">
                                    <button class="btn form-control btn-primary" style="border-radius:4px;padding: 0.375rem 0.75rem;"><i class="fa fa-1x fa-camera" style="padding-right:5px;" > </i>View all Images</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="row">
                                <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                    <table table border="0" cellpadding="0" cellspacing="0" class="box table table-hover table-styles">
                                        <thead>
                                            <tr>
                                                <th>NAME</th>
                                                <th>CHAIN</th>
                                                <th>IMAGES</th>
                                                <th>#</th>
                                            </tr>
                                        </thead>
                                        <tr>
                                            <td>Lorem Ipsum is simply dummy text of the printing industry. </td>
                                            <td> MV </td>
                                            <td> 15 </td>
                                            <td>
                                                <span @click="isEdit = true" class="desc-img" style="font-size: 15px;"> <i class="fa fa-1x fa-camera"></i> View Images</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Lorem Ipsum is simply dummy text of the printing industry. </td>
                                            <td> MV </td>
                                            <td> 15 </td>
                                            <td>
                                                <span @click="isEdit = true" class="desc-img" style="font-size: 15px;"> <i class="fa fa-1x fa-camera"></i> View Images</span>
                                            </td>
                                        </tr>
                                        <tr bgcolor="#e0eecb">
                                            <td>Lorem Ipsum is simply dummy text of the printing industry. </td>
                                            <td> MV </td>
                                            <td> 15 </td>
                                            <td>
                                                <span @click="isEdit = true" class="desc-img" style="font-size: 15px;"> <i class="fa fa-1x fa-camera"></i> View Images</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Lorem Ipsum is simply dummy text of the printing industry. </td>
                                            <td> MV </td>
                                            <td> 15 </td>
                                            <td>
                                                <span @click="isEdit = true" class="desc-img" style="font-size: 15px;"> <i class="fa fa-1x fa-camera"></i> View Images</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Lorem Ipsum is simply dummy text of the printing industry. </td>
                                            <td> MV </td>
                                            <td> 15 </td>
                                            <td>
                                                <span @click="isEdit = true" class="desc-img" style="font-size: 15px;"> <i class="fa fa-1x fa-camera"></i> View Images</span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="select-group">
                                <div class="col-12 col-sm-6 col-md-6 form-group text-right show-btn-entry">
                                    <label class="control-label select-name" for="sel1">Show</label>
                                    <div class="select-btn">
                                        <select class="form-entries" id="sel1">
                                                                          <option>1</option>
                                                                          <option>2</option>
                                                                          <option>3</option>
                                                                          <option>4</option>
                                                                       </select>
                                    </div>
                                </div>
                                <div class="select-btn">
                                    <ul class="pagination pull-right">
                                        <li class="page-item">
                                            <a class="page-link" href="#"><img class="previous1" src="../assets/images/arrow-left-gray.png"></a>
                                        </li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item active"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item"><a class="page-link" href="#">4</a></li>
                                        <li class="page-item"><a class="page-link" href="#">5</a></li>
                                        <li class="page-item">
                                            <a class="page-link" href="#"><img class="next" src="../assets/images/arrow-right-gray.png"></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <section v-bind:class="{ 'd-none': isEdit === false }" class="intro">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="box">
                            <div class="col-lg-12">
                                <div class="row header">
                                    <div class="col-12 col-sm-8 col-md-8 col-lg-8 col-xs-8 no-padding">
                                        <p>STORE DESCRIPTION: <span class="descrip-test">Lorem ipsum sit amet consectetur</span></p>
                                    </div>
                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xs-4 no-padding">
                                        <div class="btn-group pull-right go-btn">
                                            <button type="button" class="btn">go to Image</button>
                                            <button type="button" class="btn btn-success">
                                                                          <span class="caret">Go</span>
                                                                          </button>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Tablet</a></li>
                                                <li><a href="#">Smartphone</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="content" style="padding-top: 0px;">
                                <div class="list-wrapper">
                                    <div class="slider" id="main-slider">
                                        <div class="row col-lg-12">
                                            <div class="row">
                                                <div class="col-custom-1 right-side">
                                                    <div class="block sidebar-icon" style="text-align: center;">
                                                        <i class="fa fa-save" style="cursor: pointer;"></i>
                                                    </div>
                                                    <div class="block sidebar-icon" style="text-align: center;">
                                                        <i class="fa fa-save" style="cursor: pointer;"></i>
                                                    </div>
                                                    <div class="block sidebar-icon" style="text-align: center;">
                                                        <i class="fa fa-save" style="cursor: pointer;"></i>
                                                    </div>
                                                    <div class="block sidebar-icon" style="text-align: center;">
                                                        <i class="fa fa-save" style="cursor: pointer;"></i>
                                                    </div>
                                                </div>
                                                <div v-bind:class="[!isExpandImageError?'col-custom-10':'col-custom-8']">
                                                    <div class="row" style="padding:15px;">
                                                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-lg-10 slider-pagination">
                                                            <ul class="pagination">
                                                                <li>
                                                                    <a>
                                                                        <img class="previous" src="../assets/images/arrow-up-gray.png" alt="arrow-up-gray" />
                                                                    </a>
                                                                </li>
                                                                <li><a href="#slide-1">1</a></li>
                                                                <li class="page-item active"><a href="#slide-2">2</a></li>
                                                                <li><a href="#slide-3">3</a></li>
                                                                <li><a href="#slide-1">4</a></li>
                                                                <li><a href="#slide-2">5</a></li>
                                                                <li><a href="#slide-3">6</a></li>
                                                                <li><a href="#slide-1">7</a></li>
                                                                <li><a href="#slide-2">8</a></li>
                                                                <li><a href="#slide-3">9</a></li>
                                                                <li><a href="#slide-2">10</a></li>
                                                                <li><a href="#slide-3">11</a></li>
                                                                <li><a href="#slide-1">12</a></li>
                                                                <li><a href="#slide-2">13</a></li>
                                                                <li><a href="#slide-3">14</a></li>
                                                                <li><a href="#slide-1">15</a></li>
                                                                <li><a href="#slide-2">16</a></li>
                                                                <li><a href="#slide-3">17</a></li>
                                                                <li><a href="#slide-2">18</a></li>
                                                                <li><a href="#slide-3">19</a></li>
                                                                <li><a href="#slide-1">20</a></li>
                                                                <li><a href="#slide-2">21</a></li>
                                                                <li><a href="#slide-3">22</a></li>
                                                                <li><a href="#slide-1">23</a></li>
                                                                <li><a href="#slide-2">24</a></li>
                                                                <li><a href="#slide-3">25</a></li>
                                                                <li><a href="#slide-2">26</a></li>
                                                                <li><a href="#slide-3">27</a></li>
                                                                <li><a href="#slide-1">28</a></li>
                                                                <li><a href="#slide-2">29</a></li>
                                                                <li><a href="#slide-3">30</a></li>
                                                                <li>
                                                                    <a><img class="previous" src="../assets/images/arrow-up-gray.png" alt="arrow-up-gray" /> </a>
                                                                </li>
                                                                <li>
                                                                    <a><img class="previous" src="../assets/images/arrow-down-blue.png" alt="arrow-down-blue" /> </a>
                                                                </li>
                                                                <li><a href="#slide-1">31</a></li>
                                                                <li><a href="#slide-2">32</a></li>
                                                                <li><a href="#slide-3">33</a></li>
                                                                <li><a href="#slide-3">34</a></li>
                                                                <li><a href="#slide-3">35</a></li>
                                                                <li><a href="#slide-3">36</a></li>
                                                                <li><a href="#slide-3">37</a></li>
                                                                <li><a href="#slide-3">38</a></li>
                                                                <li><a href="#slide-3">39</a></li>
                                                                <li><a href="#slide-3">40</a></li>
                                                                <li><a href="#slide-3">41</a></li>
                                                                <li><a href="#slide-3">42</a></li>
                                                                <li><a href="#slide-3">43</a></li>
                                                                <li><a href="#slide-3">44</a></li>
                                                                <li><a href="#slide-3">45</a></li>
                                                                <li><a href="#slide-3">46</a></li>
                                                                <li><a href="#slide-3">47</a></li>
                                                                <li><a href="#slide-3">48</a></li>
                                                                <li><a href="#slide-3">49</a></li>
                                                                <li><a href="#slide-3">50</a></li>
                                                                <li><a href="#slide-3">51</a></li>
                                                                <li><a href="#slide-3">52</a></li>
                                                                <li><a href="#slide-3">53</a></li>
                                                                <li><a href="#slide-3">54</a></li>
                                                                <li><a href="#slide-3">55</a></li>
                                                                <li><a href="#slide-3">56</a></li>
                                                                <li><a href="#slide-3">57</a></li>
                                                                <li><a href="#slide-3">58</a></li>
                                                                <li><a href="#slide-3">59</a></li>
                                                                <li><a href="#slide-3">60</a></li>
                                                                <li>
                                                                    <a><img class="previous" src="../assets/images/arrow-down-blue.png" alt="arrow-down-blue" /> </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                                                            <div class="zoom-btn">
                                                                <input type="button" class="z-btn" value="+" onclick="zoom(1.1)" />
                                                                <input type="button" class="z-btn" value="-" onclick="zoom(0.9)" />
                                                            </div>
                                                            <div class="pages">1 out of 20</div>
                                                            <div class="slider-wrapper">
                                                                <div class="slide link-gallery" id="slide-1 imagediv" data-toggle="modal" data-target="#modalGallery">
                                                                    <img id="pic" src="../assets/images/student-849825_960_720.jpg" alt="student-849825_960_720" class="img-responsive img-gallery">
                                                                </div>
                                                                <div class="slide link-gallery" id="slide-2 imagediv" data-toggle="modal" data-target="#modalGallery">
                                                                    <img id="pic" src="../assets/images/work-731198_960_720.jpg" alt="work-731198_960_720" class="img-responsive img-gallery">
                                                                </div>
                                                                <div class="slide link-gallery" id="slide-3 imagediv" data-toggle="modal" data-target="#modalGallery">
                                                                    <img id="pic" src="../assets/images/write-593333_960_720.jpg" class="img-responsive img-gallery" alt="Third image">
                                                                </div>
                                                            </div>
                                                            <div class="slider-nav">
                                                                <button class="slider-previous">Previous</button>
                                                                <button class="slider-next">Next</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div v-bind:class="[!isExpandImageError?'col-custom-1 right-side':'col-custom-3 right-side']">
                                                    <div class="vertical-text" v-if="!isExpandImageError">
                                                        <i @click="isExpandImageError = true" class="fa fa-chevron-right" style="cursor: pointer;"></i> &nbsp; &nbsp;Image Errors & Promotions
                                                    </div>
                                                    <div v-if="isExpandImageError" class="text-left">
                                                        <div><i @click="isExpandImageError = false" class="fa fa-chevron-left text-left" style="cursor: pointer;"></i></div>
                                                        <br />
                                                        <div class="container-fluid">
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="box">
                                                                        <div class="col-lg-12">
                                                                            <div class="row header">Image Errors</div>
                                                                        </div>
                                                                        <div class="content fontgray" style="padding:5px 10px 10px;">
                                                                            <b-form-group label="">
                                                                                <b-form-checkbox-group stacked name="errors" :options="options">
                                                                                </b-form-checkbox-group>
                                                                            </b-form-group>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="box">
                                                                        <div class="col-lg-12">
                                                                            <div class="row header">Promations</div>
                                                                        </div>
                                                                        <div class="content fontgray" style="padding:5px 10px 10px;">
                                                                            <b-list-group>
                                                                                <b-list-group-item href="#">Cras justo odio</b-list-group-item>
                                                                                <b-list-group-item href="#">Dapibus ac facilisis in</b-list-group-item>
                                                                                <b-list-group-item href="#">Morbi leo risus</b-list-group-item>
                                                                                <b-list-group-item href="#">Porta ac consectetur ac</b-list-group-item>
                                                                                <b-list-group-item href="#">Vestibulum at eros</b-list-group-item>
                                                                            </b-list-group>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script lang="js">
    export default {
        name: 'product-locator',
        props: [],
        mounted() {},
        data() {
            return {
                isSearch: true,
                isEdit: false,
                isExpandImageError: false,
                options: [{
                        text: 'Bury',
                        value: 'Bury'
                    },
                    {
                        text: 'Error 2',
                        value: 'Error 2'
                    },
                    {
                        text: 'Error 3',
                        value: 'Error 3'
                    },
                    {
                        text: 'Error 4',
                        value: 'Error 4'
                    },
                    {
                        text: 'Error 5',
                        value: 'Error 5'
                    },
                    {
                        text: 'Error 6',
                        value: 'Error 6'
                    }
                ]
            }
        },
        methods: {
    
        },
        computed: {
    
        }
    }
</script>

<style lang="scss" scoped>
    section .external-user {
        border-bottom: #E9E9E9 1px solid;
        padding: 10px 15px;
        font-family: OpenSans;
        color: #6f6f6f;
        font-size: 12px;
    }
    
    .sidebar-icon {
        padding-top: 5px;
        padding-bottom: 5px;
    }
    
    @media (min-width: 992px) {
        .col-custom-1 {
            -ms-flex: 0 0 5%;
            -webkit-box-flex: 0;
            flex: 0 0 5%;
            max-width: 5%;
            padding: 10px
        }
        .col-custom-10 {
            -ms-flex: 0 0 90%;
            -webkit-box-flex: 0;
            flex: 0 0 90%;
            max-width: 90%;
        }
        .col-custom-3 {
            -ms-flex: 0 0 30%;
            -webkit-box-flex: 0;
            flex: 0 0 30%;
            max-width: 30%;
            padding: 10px
        }
        .col-custom-8 {
            -ms-flex: 0 0 65%;
            -webkit-box-flex: 0;
            flex: 0 0 65%;
            max-width: 65%;
        }
    }
    
    @media (min-width: 992px) {
        .col-custom-1 {
            -ms-flex: 0 0 5%;
            -webkit-box-flex: 0;
            flex: 0 0 5%;
            max-width: 5%;
            padding: 10px
        }
        .col-custom-10 {
            -ms-flex: 0 0 90%;
            -webkit-box-flex: 0;
            flex: 0 0 90%;
            max-width: 90%;
        }
        .col-custom-3 {
            -ms-flex: 0 0 30%;
            -webkit-box-flex: 0;
            flex: 0 0 30%;
            max-width: 30%;
            padding: 10px
        }
        .col-custom-8 {
            -ms-flex: 0 0 65%;
            -webkit-box-flex: 0;
            flex: 0 0 65%;
            max-width: 65%;
        }
    }
    
    @media (min-width: 768px) {
        .col-custom-1 {
            -ms-flex: 0 0 5%;
            -webkit-box-flex: 0;
            flex: 0 0 5%;
            max-width: 5%;
            padding: 10px
        }
        .col-custom-10 {
            -ms-flex: 0 0 90%;
            -webkit-box-flex: 0;
            flex: 0 0 90%;
            max-width: 90%;
        }
        .col-custom-3 {
            -ms-flex: 0 0 30%;
            -webkit-box-flex: 0;
            flex: 0 0 30%;
            max-width: 30%;
            padding: 10px
        }
        .col-custom-8 {
            -ms-flex: 0 0 65%;
            -webkit-box-flex: 0;
            flex: 0 0 65%;
            max-width: 65%;
        }
    }
    
    @media (min-width: 576px) {
        .col-custom-1 {
            -ms-flex: 0 0 5%;
            -webkit-box-flex: 0;
            flex: 0 0 5%;
            max-width: 5%;
            padding: 0px;
        }
        .col-custom-10 {
            -ms-flex: 0 0 90%;
            -webkit-box-flex: 0;
            flex: 0 0 90%;
            max-width: 90%;
        }
        .col-custom-3 {
            -ms-flex: 0 0 30%;
            -webkit-box-flex: 0;
            flex: 0 0 30%;
            max-width: 30%;
            padding: 10px
        }
        .col-custom-8 {
            -ms-flex: 0 0 65%;
            -webkit-box-flex: 0;
            flex: 0 0 65%;
            max-width: 65%;
        }
    }
    
    .right-side {
        box-shadow: 0px 1px 5px #b7aeae;
        webkit-box-shadow: 0px 1px 5px #b7aeae;
    }
    
    .left-side {
        box-shadow: 0px 1px 5px #b7aeae;
        webkit-box-shadow: 0px 1px 5px #b7aeae;
    }
</style>
