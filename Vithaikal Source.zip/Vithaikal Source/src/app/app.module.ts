import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './shared/pages/menu/menu.component';
import { HeaderComponent } from './shared/pages/header/header.component';
import { LayoutComponent } from './shared/pages/layout/layout.component';
import { FooterComponent } from './shared/pages/footer/footer.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';

import { routing } from './app.routing';
import { ContentComponent } from './pages/content/content.component';
import { ContactComponent } from './pages/contact/contact.component';
import { AboutComponent } from './pages/about/about.component';
import { PrivacyComponent } from './pages/privacy/privacy.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    HeaderComponent,
    LayoutComponent,
    FooterComponent,
    DashboardComponent,
    ContentComponent,
    ContactComponent,
    AboutComponent,
    PrivacyComponent,
  ],
  imports: [
    routing,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
