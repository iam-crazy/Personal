import { Routes } from '@angular/router';
import { Component } from '@angular/core';
import { LayoutComponent } from './shared/pages/layout/layout.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { RouterModule } from '@angular/router';
import { ContentComponent } from './pages/content/content.component';
import { ContactComponent } from './pages/contact/contact.component';
import { AboutComponent } from './pages/about/about.component';
import { PrivacyComponent } from './pages/privacy/privacy.component';

const appRoutes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        component: DashboardComponent
      },
      {
        path: 'content/:data',
        component: ContentComponent
      },
      {
        path: 'contact',
        component: ContactComponent
      },
      {
        path: 'about',
        component: AboutComponent
      },
      {
        path: 'privacy',
        component: PrivacyComponent
      }
    ]
  }
];

export const routing = RouterModule.forChild(appRoutes);
