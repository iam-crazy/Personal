export class NewsContent {
  title: string;
  url?: string;
  imageurl?: string;
  youtubeurl?: any;
  safeyoutubeurl?: any;
  content: string;
  category: string;
  lastUpdatedOn?: Date;
}

export const NewsContents: NewsContent[] = [
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தமிழகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தமிழகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தமிழகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தமிழகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தமிழகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "இந்தியா",
    lastUpdatedOn: new Date()
  },
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "இந்தியா",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "இந்தியா",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "இந்தியா",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "உலகம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "உலகம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "உலகம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "உலகம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "உலகம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "உலகம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விளையாட்டு",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விளையாட்டு",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விளையாட்டு",
    lastUpdatedOn: new Date()
  },
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விளையாட்டு",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விளையாட்டு",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விஞ்ஞானம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விஞ்ஞானம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விஞ்ஞானம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "விஞ்ஞானம்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "சினிமா",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "சினிமா",
    lastUpdatedOn: new Date()
  },
  {
    title: "மத்திய பிரதேச தேர்தல்",
    content:
      "காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு! பாக்.காங்கிரஸ் வேட்பாளர் பட்டியல் வெளியீடு!",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "தாயகச் செய்திகள்",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "சினிமா",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "சினிமா",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    imageurl:
      "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201409/new-modi_650_092814115442.jpg",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "சினிமா",
    lastUpdatedOn: new Date()
  },
  {
    title: "ஏமாற்றியதை தாங்க முடியலை",
    content:
      "அதான் குத்தி கொன்னுட்டேன்.. ஆசிரியையை கொன்றவர் பரபரஅதான் குத்தி கொன்னுட்டேன்.. ",
    youtubeurl: "https://www.youtube.com/embed/xxT4hXkfX_8",
    url:
      "https://stackoverflow.com/questions/36095496/angular-2-how-to-write-a-for-loop-not-a-foreach-loop",
    category: "சினிமா",
    lastUpdatedOn: new Date()
  }
];
