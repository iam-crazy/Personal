import { Component, OnInit } from "@angular/core";
import { NewsContent, NewsContents } from "./../../model/NewsContent";
import { ActivatedRoute } from "@angular/router";
import { DomSanitizer } from "@angular/platform-browser";

@Component({
  selector: "app-content",
  templateUrl: "./content.component.html",
  styleUrls: ["./content.component.css"]
})
export class ContentComponent implements OnInit {
  public contents;
  public title;
  public dateFormat;
  constructor(public route: ActivatedRoute, public sanitizer: DomSanitizer) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      const da = params["data"];
      this.title = da;
      var dd = NewsContents.filter(function(s) {
        return s.category === da;
      });
      var y = this;
      dd.forEach(function(v) {
        if (v.youtubeurl && v.youtubeurl.length > 0) {
          v.safeyoutubeurl = y.sanitizer.bypassSecurityTrustResourceUrl(
            v.youtubeurl
          );
        }
      });
      this.contents = NewsContents.filter(function(s) {
        return s.category === da;
      });
      this.dateFormat = "MMMM dd, yyyy";
    });
  }
}
