export class Menu {
  name: string;
  url: string;
  submenus: Menu[];
  icon: string;
}

export const Menus = [
  {
    name: 'தாயகச் செய்திகள்',
    url: '/content/தாயகச் செய்திகள்'
  },
  {
    name: 'தமிழகச் செய்திகள்',
    url: '/content/தமிழகச் செய்திகள்'
  },
  {
    name: 'இந்தியா',
    url: '/content/இந்தியா'
  },
  {
    name: 'உலகம் ',
    url: '/content/உலகம்'
  },
  {
    name: 'விளையாட்டு ',
    url: '/content/விளையாட்டு'
  },
  {
    name: 'விஞ்ஞானம் ',
    url: '/content/விஞ்ஞானம்'
  },
  {
    name: 'சினிமா ',
    url: '/content/சினிமா'
  },
  {
    name: 'மேலும் ',
    url: '#',
    submenus: [
      {
        name: 'தொடர்புக்கு ',
        url: '/contact'
      },
      {
        name: 'விதைகள் ',
        url: '/about'
      },
      {
        name: 'தனியுரிமை கொள்கை',
        url: '/privacy'
      }
    ]
  }
];
