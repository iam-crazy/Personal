import { Component, OnInit } from '@angular/core';
import { MenuComponent } from '../menu/menu.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public currentDateTime;
  public dateFormat;
  constructor() {
    this.currentDateTime = new Date();
    // this.dateFormat = 'dd MMMM yyyy hh:mm:ss (UTC Z)';
    this.dateFormat = 'EEEE, dd MMMM yyyy hh:mm:ss';
    setInterval(() => {
      this.currentDateTime = new Date();
    }, 500);
  }

  ngOnInit() {}
}
